' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Colors

Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices

Public Class AsdkClass1


    'This function returns the ObjectId for the BlockTableRecord called "EmployeeBlock",
    'creating it if necessary.  The block contains three entities - circle, text 
    'and ellipse.
    Private Function CreateEmployeeDefinition() As ObjectId
        Dim newBtrId As ObjectId 'The return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase() 'save some space
        Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction
            'Now, drill into the database and obtain a reference to the BlockTable
            Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
            If (bt.Has("EmployeeBlock")) Then
                newBtrId = bt("EmployeeBlock") 'Alreayd there...no need to recreate it!
            Else
                Dim center As New Point3d(10, 10, 0) 'convenient declaration...

                'Declare and define the entities we want to add:
                'Circle:
                Dim circle As Circle = New Circle(center, Vector3d.ZAxis, 2.0)
                'Text:
                Dim text As MText = New MText()
                text.Contents = "Earnest Shackleton"
                text.Location = center
                'Ellipse:
                Dim ellipse As Ellipse = New Ellipse(center, Vector3d.ZAxis, New Vector3d(3, 0, 0), 0.5, 0.0, 0.0)

                'Next, create a layer with the helper function, and assign
                'the layer to our entities.
                Dim empId As ObjectId = CreateLayer("EmployeeLayer")
                text.LayerId = empId
                circle.LayerId = empId
                ellipse.LayerId = empId
                'Set the color for each entity irrespective of the layer's color.
                text.ColorIndex = 2
                circle.ColorIndex = 1
                ellipse.ColorIndex = 3

                'Create a new block definition called EmployeeBlock
                Dim newBtr As BlockTableRecord = New BlockTableRecord()
                newBtr.Name = "EmployeeBlock"
                newBtrId = bt.Add(newBtr) 'Add the block, and set the id as the return value of our function
                trans.AddNewlyCreatedDBObject(newBtr, True) 'Let the transaction know about any object/entity you add to the database!

                newBtr.AppendEntity(circle) 'Append our entities...
                newBtr.AppendEntity(text)
                newBtr.AppendEntity(ellipse)
                trans.AddNewlyCreatedDBObject(circle, True) 'Again, let the transaction know about our newly added entities.
                trans.AddNewlyCreatedDBObject(text, True)
                trans.AddNewlyCreatedDBObject(ellipse, True)
            End If
            trans.Commit() 'All done, no errors?  Go ahead and commit!
        End Using
        CreateDivision() 'Create the Employee Division dictionaries.
        Return newBtrId
    End Function

    'This function creates a new BlockReference to the "EmployeeBlock" object,
    'and adds it to ModelSpace.
    <CommandMethod("CREATE")> _
        Public Sub CreateEmployee()
        Dim db As Database = HostApplicationServices.WorkingDatabase()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction()
                Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
                Dim btr As BlockTableRecord = trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite)
                'Create the block reference...use the return from CreateEmployeeDefinition directly!
                Dim br As New BlockReference(New Point3d(10, 10, 0), CreateEmployeeDefinition())
                btr.AppendEntity(br) 'Add the reference to ModelSpace
                trans.AddNewlyCreatedDBObject(br, True) 'Let the transaction know about it

                'Create the custom per-employee data
                Dim xRec As New Xrecord()
                'We want to add 'Name', 'Salary' and 'Division' information.  Here is how:
                xRec.Data = New ResultBuffer( _
                        New TypedValue(DxfCode.Text, "Earnest Shackleton"), _
                        New TypedValue(DxfCode.Real, 72000), _
                        New TypedValue(DxfCode.Text, "Sales"))

                'Next, we need to add this data to the 'Extension Dictionary' of the employee.
                br.CreateExtensionDictionary()
                Dim brExtDict As DBDictionary = trans.GetObject(br.ExtensionDictionary(), OpenMode.ForWrite, False)
                brExtDict.SetAt("EmployeeData", xRec) 'Set our XRecord in the dictionary at 'EmployeeData'.
                trans.AddNewlyCreatedDBObject(xRec, True)

                trans.Commit()
            End Using

        Catch ex As System.Exception
            ed.WriteMessage("Error Creating Employee: " + ex.Message)
        End Try
    End Sub

    'This function returns the objectId for the "EmployeeLayer", creating it if necessary.
    Private Function CreateLayer(ByVal layerName As String) As ObjectId
        Dim layerId As ObjectId 'the return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using trans As Transaction = db.TransactionManager.StartTransaction()
            'Get the layer table first...
            Dim lt As LayerTable = trans.GetObject(db.LayerTableId, OpenMode.ForRead)

            'Check if EmployeeLayer exists...
            If lt.Has(layerName) Then
                layerId = lt.Item(layerName)
            Else
                'If not, create the layer here.
                lt.UpgradeOpen()
                Dim ltr As LayerTableRecord = New LayerTableRecord()
                ltr.Name = layerName ' Set the layer name
                ltr.Color = Color.FromColorIndex(ColorMethod.ByAci, 2)
                layerId = lt.Add(ltr)
                trans.AddNewlyCreatedDBObject(ltr, True)
            End If
            trans.Commit()
        End Using
        Return layerId
    End Function

    Private Sub CreateDivision()
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using trans As Transaction = db.TransactionManager.StartTransaction()
            'First, get the NOD...
            Dim NOD As DBDictionary = trans.GetObject(db.NamedObjectsDictionaryId, OpenMode.ForWrite, False)
            'Define a corporate level dictionary
            Dim acmeDict As DBDictionary
            Try
                'if it exists, just get it
                acmeDict = trans.GetObject(NOD.GetAt("ACME_DIVISION"), OpenMode.ForRead)
            Catch
                'Doesn't exist, so create one
                acmeDict = New DBDictionary()
                NOD.SetAt("ACME_DIVISION", acmeDict)
                trans.AddNewlyCreatedDBObject(acmeDict, True)
            End Try

            'Now get the division we want from acmeDict
            Dim divDict As DBDictionary
            Try
                divDict = trans.GetObject(acmeDict.GetAt("Sales"), OpenMode.ForWrite)
            Catch
                divDict = New DBDictionary() 'Division doesn't exist, create one
                acmeDict.UpgradeOpen()
                acmeDict.SetAt("Sales", divDict)
                trans.AddNewlyCreatedDBObject(divDict, True)
            End Try

            'Now get the manager info from the division
            'We need to add the name of the division supervisor.  We'll do this with another XRecord.
            Dim mgrXRec As Xrecord
            Try
                mgrXRec = trans.GetObject(divDict.GetAt("Department Manager"), OpenMode.ForWrite)
            Catch
                mgrXRec = New Xrecord()
                mgrXRec.Data = New ResultBuffer(New TypedValue(DxfCode.Text, "Randolph P. Brokwell"))
                divDict.SetAt("Department Manager", mgrXRec)
                trans.AddNewlyCreatedDBObject(mgrXRec, True)
            End Try
            trans.Commit()
        End Using
    End Sub

    <CommandMethod("EMPLOYEECOUNT")> _
        Public Sub EmployeeCount()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim nEmployeeCount As Integer = 0
        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction() 'Start the transaction.
                'First, get at the BlockTable, and the ModelSpace BlockTableRecord
                Dim bt As BlockTable = trans.GetObject(HostApplicationServices.WorkingDatabase.BlockTableId, OpenMode.ForRead)
                Dim btr As BlockTableRecord = trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead)
                'Now, here is the fun part.  This is where we iterate through ModelSpace:
                Dim id As ObjectId ' - First, dimension an ID variable used in the For Loop.
                For Each id In btr
                    Dim ent As Entity = trans.GetObject(id, OpenMode.ForRead, False) 'Use it to open the current object!
                    If TypeOf ent Is BlockReference Then 'We use .NET's RTTI to establish type.
                        nEmployeeCount += 1
                    End If
                Next
                ed.WriteMessage("Employees Found: {0}" + ControlChars.Lf, nEmployeeCount.ToString())
                trans.Commit()
            End Using
        Catch ex As System.Exception
            ed.WriteMessage("Error Counting Employees: " + ex.Message)
        End Try
    End Sub
End Class