' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime

Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput

Public Class ASDKClass1

  <CommandMethod("selectpoint")> _
  Public Sub Asdkcmd1()
        ' now get the active drawing autocad editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' try the code
        Try

            ' setup the Command line prompt string
            Dim prPointOptions As PromptPointOptions = New PromptPointOptions("Select a point")

            Dim prPointRes As PromptPointResult

            prPointRes = ed.GetPoint(prPointOptions)
            ' lets check the return status, if it's not ok simply return
            If prPointRes.Status <> PromptStatus.OK Then
                Return
            End If

            ' ok - all ok - we've obtained a point selection from the user
            ed.WriteMessage("You selected point " & prPointRes.Value.ToString)
        Catch ex As System.Exception
            ' an exception has been thrown
            ed.WriteMessage("Error in Selecting Points" + ex.Message)
        End Try

  End Sub

  <CommandMethod("getDistance")> _
  Public Sub getdistance()
        ' very similar to above 
        ' now get the active drawing autocad editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try

            ' setup the Command line prompt string
            Dim prDistOptions As PromptDistanceOptions = New PromptDistanceOptions("Find distance, select first point:")

            Dim prDistRes As PromptDoubleResult
            ' and now ask the user to pick a distance
            prDistRes = ed.GetDistance(prDistOptions)
            ' lets check the return status, if it's not ok simply return
            If prDistRes.Status <> PromptStatus.OK Then
                Return
            End If

            ' ok - all ok - we've obtained a point selection from the user
            ed.WriteMessage("The distance is: " & prDistRes.Value.ToString)

        Catch ex As System.Exception
            ed.WriteMessage("Error Getting Distance" + ex.Message)
        End Try
  End Sub


End Class
