' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'
'Lab 7 code begins here

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices

Public Class AsdkClass2

    'Global variables
    Dim bEditCommand As Boolean
    Dim bDoRepositioning As Boolean
    Dim changedObjects As New ObjectIdCollection()
    Dim employeePositions As New Point3dCollection()

    <CommandMethod("AddEvents")> _
    Public Sub plantDbEvents()
        'To avoid ambiguity, we have to use the full type here.
        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = HostApplicationServices.WorkingDatabase()
        AddHandler db.ObjectOpenedForModify, New ObjectEventHandler(AddressOf objOpenedForMod)
        AddHandler doc.CommandWillStart, New CommandEventHandler(AddressOf cmdWillStart)
        AddHandler doc.CommandEnded, New CommandEventHandler(AddressOf cmdEnded)
        bEditCommand = False
        bDoRepositioning = False
    End Sub

    <CommandMethod("RemoveEvents")> _
    Public Sub removeDbEvents()
        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = HostApplicationServices.WorkingDatabase()
        RemoveHandler db.ObjectOpenedForModify, AddressOf objOpenedForMod
        RemoveHandler doc.CommandEnded, AddressOf cmdEnded
        RemoveHandler doc.CommandWillStart, AddressOf cmdWillStart
        bEditCommand = False
        bDoRepositioning = False
    End Sub

    Public Sub objOpenedForMod(ByVal o As Object, ByVal e As ObjectEventArgs)
        If bEditCommand = False Or bDoRepositioning = True Then
            Return
        End If

        Dim objId As ObjectId = e.DBObject.ObjectId
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction()

                Dim ent As Entity = trans.GetObject(objId, OpenMode.ForRead, False) 'Use it to open the current object!
                If TypeOf ent Is BlockReference Then 'We use .NET's RTTI to establish type.
                    Dim br As BlockReference = CType(ent, BlockReference)
                    'Test whether it is an employee block
                    'open its extension dictionary
                    If br.ExtensionDictionary().IsValid Then
                        Dim brExtDict As DBDictionary = trans.GetObject(br.ExtensionDictionary(), OpenMode.ForRead)
                        If brExtDict.GetAt("EmployeeData").IsValid Then
                            'successfully got "EmployeeData" so br is employee block ref

                            'Store the objectID and the position
                            changedObjects.Add(objId)
                            employeePositions.Add(br.Position)
                            'Get the attribute references,if any
                            Dim atts As AttributeCollection
                            atts = br.AttributeCollection
                            If atts.Count > 0 Then
                                Dim attId As ObjectId
                                For Each attId In atts
                                    Dim att As AttributeReference
                                    att = trans.GetObject(attId, OpenMode.ForRead, False)
                                    changedObjects.Add(attId)
                                    employeePositions.Add(att.Position)
                                Next
                            End If
                        End If
                    End If
                End If
                trans.Commit()
            End Using
        Catch ex As System.Exception
            ed.WriteMessage("Error in objOpenedForMod: " + ex.Message)
        End Try
    End Sub

    Public Sub cmdWillStart(ByVal o As Object, ByVal e As CommandEventArgs)
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            If e.GlobalCommandName = "MOVE" Then
                'Set the global variables
                bEditCommand = True
                bDoRepositioning = False
                'Delete all stored information
                changedObjects.Clear()
                employeePositions.Clear()
            End If
        Catch ex As System.Exception
            ed.WriteMessage("Error in cmdWillStart: " + ex.Message)
        End Try
    End Sub

    Public Sub cmdEnded(ByVal o As Object, ByVal e As CommandEventArgs)
        'Was our monitored command active?
        If bEditCommand = False Then
            Return
        End If

        bEditCommand = False

        'Set flag to bypass OpenedForModify handler
        bDoRepositioning = True

        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try

            Dim db As Database = HostApplicationServices.WorkingDatabase
            Dim oldpos As Point3d
            Dim newpos As Point3d
            For i As Integer = 0 To changedObjects.Count - 1
                Using trans As Transaction = db.TransactionManager.StartTransaction()
                    Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForRead)
                    Dim ent As Entity = CType(trans.GetObject(changedObjects.Item(i), OpenMode.ForWrite), Entity)
                    If TypeOf ent Is BlockReference Then 'We use .NET's RTTI to establish type.
                        Dim br As BlockReference = CType(ent, BlockReference)
                        newpos = br.Position
                        oldpos = employeePositions.Item(i)

                        'Reset blockref position
                        If Not oldpos.Equals(newpos) Then
                            trans.GetObject(br.ObjectId, OpenMode.ForWrite)
                            br.Position = oldpos
                        End If
                    ElseIf TypeOf ent Is AttributeReference Then
                        Dim att As AttributeReference = CType(ent, AttributeReference)
                        newpos = att.Position
                        oldpos = employeePositions.Item(i)

                        'Reset attref position
                        If Not oldpos.Equals(newpos) Then
                            trans.GetObject(att.ObjectId, OpenMode.ForWrite)
                            att.Position = oldpos
                        End If
                    End If
                    trans.Commit()
                End Using
            Next
        Catch ex As System.Exception
            ed.WriteMessage("Error in cmdEnded: " + ex.Message)
        End Try
    End Sub
End Class 'End of Lab7 code