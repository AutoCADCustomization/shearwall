' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Colors

Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices

Public Class AsdkClass1

#Region "CreateEmployeeDefinition"
    'This function returns the ObjectId for the BlockTableRecord called "EmployeeBlock",
    'creating it if necessary.  The block contains three entities - circle, text 
    'and ellipse.
    Private Function CreateEmployeeDefinition() As ObjectId

        Dim newBtrId As ObjectId 'The return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase() 'save some space
        Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction
            ' access the database and obtain a reference to the BlockTable
            Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
            If (bt.Has("EmployeeBlock")) Then
                newBtrId = bt("EmployeeBlock") 'Alreayd there...no need to recreate it!
            Else
                Dim center As New Point3d(0, 0, 0)

                'Declare and define the entities we want to add:
                'Circle:
                Dim circle As Circle = New Circle(center, Vector3d.ZAxis, 2.0)

                'Attribute
                Dim attDef As AttributeDefinition = New AttributeDefinition(center, "NoName", "Name:", "Enter Name", db.Textstyle)

                'Ellipse:
                Dim ellipse As Ellipse = New Ellipse(center, Vector3d.ZAxis, New Vector3d(3, 0, 0), 0.5, 0.0, 0.0)

                'Next, create a layer with the helper function, and assign
                'the layer to our entities.
                Dim empId As ObjectId = CreateLayer()
                circle.LayerId = empId
                ellipse.LayerId = empId
                'Set the color for each entity irrespective of the layer's color.
                attDef.ColorIndex = 2
                circle.ColorIndex = 1
                ellipse.ColorIndex = 3

                'Create a new block definition called EmployeeBlock
                Dim newBtr As BlockTableRecord = New BlockTableRecord()
                newBtr.Name = "EmployeeBlock"
                newBtrId = bt.Add(newBtr) 'Add the block, and set the id as the return value of our function
                trans.AddNewlyCreatedDBObject(newBtr, True) 'Let the transaction know about any object/entity you add to the database!

                newBtr.AppendEntity(circle) 'Append our entities...
                newBtr.AppendEntity(attDef)
                newBtr.AppendEntity(ellipse)
                trans.AddNewlyCreatedDBObject(circle, True) 'Again, let the transaction know about our newly added entities.
                trans.AddNewlyCreatedDBObject(attDef, True)
                trans.AddNewlyCreatedDBObject(ellipse, True)
            End If
            trans.Commit() 'All done, no errors?  Go ahead and commit!
        End Using
        Return newBtrId
    End Function
#End Region

#Region "CreateEmployeeCommand"
    'comand to create employee
    <CommandMethod("CREATE")> _
    Public Sub Create()

        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction()
                'Prompts for each employee detail
                Dim prName As PromptStringOptions = New PromptStringOptions("Enter Employee Name")
                Dim prDiv As PromptStringOptions = New PromptStringOptions("Enter Employee Division")
                Dim prSal As PromptDoubleOptions = New PromptDoubleOptions("Enter Employee Salary")
                Dim prPos As PromptPointOptions = New PromptPointOptions("Enter Employee Position or")

                'Add keywords when prompting for position
                prPos.Keywords.Add("Name")
                prPos.Keywords.Add("Division")
                prPos.Keywords.Add("Salary")

                'Set the default values for each of these
                prName.DefaultValue = "Earnest Shackleton"
                prDiv.DefaultValue = "Sales"
                prSal.DefaultValue = 10000.0F

                'Set conditions for prompting
                prPos.AllowNone = False 'Do not allow null values

                'prompt results
                Dim prNameRes As PromptResult = Nothing
                Dim prDivRes As PromptResult = Nothing
                Dim prSalRes As PromptDoubleResult = Nothing
                Dim prPosRes As PromptPointResult = Nothing

                'Loop to get employee details. Exit the loop when positon is entered
                Do
                    'Prompt for position
                    prPosRes = ed.GetPoint(prPos)

                    If prPosRes.Status = PromptStatus.Keyword Then 'Got a keyword
                        Select Case (prPosRes.StringResult)
                            Case "Name"
                                'Get employee name
                                prName.AllowSpaces = True
                                prNameRes = ed.GetString(prName)
                                If prNameRes.Status <> PromptStatus.OK Then
                                    Throw New System.Exception("Error or User Cancelled Input")
                                End If
                            Case "Division"
                                'Get employee division
                                prDiv.AllowSpaces = True
                                prDivRes = ed.GetString(prDiv)
                                If prDivRes.Status <> PromptStatus.OK Then
                                    Throw New System.Exception("Error or User Cancelled Input")
                                End If
                            Case "Salary"
                                'Get employee salary
                                prSal.AllowNegative = False
                                prSal.AllowNone = True
                                prSal.AllowZero = False
                                prSalRes = ed.GetDouble(prSal)
                                If prSalRes.Status <> PromptStatus.OK And prSalRes.Status <> PromptStatus.None Then
                                    Throw New System.Exception("Error or User Cancelled Input")
                                End If
                            Case Else
                                Throw New System.Exception("Error or User Cancelled Input")
                        End Select
                    End If
                    If prPosRes.Status = PromptStatus.Cancel Or prPosRes.Status = PromptStatus.Error Then
                        Throw New System.Exception("Error or User Cancelled")
                    End If
                Loop While (prPosRes.Status <> PromptStatus.OK)

                'Create the Employee - either use the input value or the default value...
                Dim name As String
                If prNameRes Is Nothing Then
                    name = prName.DefaultValue
                Else
                    name = prNameRes.StringResult
                End If

                Dim division As String
                If prDivRes Is Nothing Then
                    division = prDiv.DefaultValue
                Else
                    division = prDivRes.StringResult
                End If

                Dim salary As Double
                If prSalRes Is Nothing Then
                    salary = prSal.DefaultValue
                Else
                    salary = prSalRes.Value
                End If

                'Create the Employee
                CreateEmployee(name, division, salary, prPosRes.Value)

                Dim manager As String = New String("")

                'Now create the division 
                'Pass an empty string for manager to check if it already exists
                Dim depMgrXRec As Xrecord
                Dim xRecId As ObjectId
                xRecId = CreateDivision(division, manager)

                'Open the department manager XRecord
                depMgrXRec = trans.GetObject(xRecId, OpenMode.ForRead)

                Dim val As TypedValue
                For Each val In depMgrXRec.Data
                    Dim str As String
                    str = val.Value
                    If str = "" Then
                        ' Manager was not set, now set it
                        ' Prompt for  manager name first
                        ed.WriteMessage(vbCrLf)
                        Dim prManagerName As PromptStringOptions = New PromptStringOptions("No manager set for the division! Enter Manager Name")
                        prManagerName.DefaultValue = "Delton T. Cransley"
                        prManagerName.AllowSpaces = True
                        Dim prManagerNameRes As PromptResult = ed.GetString(prManagerName)
                        If prManagerNameRes.Status <> PromptStatus.OK Then
                            Throw New System.Exception("Error or User Cancelled Input")
                        End If

                        'Set a manager name
                        depMgrXRec.Data = New ResultBuffer(New TypedValue(DxfCode.Text, prManagerNameRes.StringResult))
                    End If
                Next
                trans.Commit()
            End Using
        Catch ex As System.Exception
            ed.WriteMessage("Error Creating Employee: " + ex.Message)
        End Try
    End Sub
#End Region

#Region "CreateEmployee"
    'This function creates a new BlockReference to the "EmployeeBlock" object,
    'and adds it to ModelSpace.  _
    Private Function CreateEmployee(ByVal name As String, ByVal division As String, ByVal salary As Double, ByVal pos As Point3d) As ObjectId
        Dim retId As ObjectId 'the return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase()

        Using trans As Transaction = db.TransactionManager.StartTransaction()
            Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
            Dim btr As BlockTableRecord = trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite)
            'Create the block reference...use the return from CreateEmployeeDefinition directly!
            Dim br As New BlockReference(pos, CreateEmployeeDefinition())
            ' create a new attribute reference
            Dim attRef As AttributeReference = New AttributeReference()

            'Iterate the employee block and find the attribute definition
            Dim empBtr As BlockTableRecord = trans.GetObject(bt("EmployeeBlock"), OpenMode.ForRead)

            Dim id As ObjectId

            For Each id In empBtr
                Dim ent As Entity = trans.GetObject(id, OpenMode.ForRead, False) 'Use it to open the current object! 
                If TypeOf ent Is AttributeDefinition Then 'We use .NET's RTTI to establish type.
                    'Set the properties from the attribute definition on our attribute reference
                    Dim attDef As AttributeDefinition = CType(ent, AttributeDefinition)
                    attRef.SetAttributeFromBlock(attDef, br.BlockTransform)
                    attRef.TextString = name

                End If
            Next

            btr.AppendEntity(br) 'Add the reference to ModelSpace

            'Add the attribute reference to the block reference
            br.AttributeCollection.AppendAttribute(attRef)

            'let the transaction know
            trans.AddNewlyCreatedDBObject(attRef, True)
            trans.AddNewlyCreatedDBObject(br, True) 'Let the transaction know about it

            'Create the custom per-employee data
            Dim xRec As New Xrecord()
            'We want to add 'Name', 'Salary' and 'Division' information.  Here is how:
            xRec.Data = New ResultBuffer( _
                    New TypedValue(DxfCode.Text, name), _
                    New TypedValue(DxfCode.Real, salary), _
                    New TypedValue(DxfCode.Text, division))

            'Next, we need to add this data to the 'Extension Dictionary' of the employee.
            br.CreateExtensionDictionary()
            Dim brExtDict As DBDictionary = trans.GetObject(br.ExtensionDictionary(), OpenMode.ForWrite, False)
            brExtDict.SetAt("EmployeeData", xRec) 'Set our XRecord in the dictionary at 'EmployeeData'.
            trans.AddNewlyCreatedDBObject(xRec, True)

            retId = br.ObjectId
            trans.Commit()
        End Using

        'Return the objectId of the employee block reference
        Return retId
    End Function
#End Region

#Region "CreateLayer"
    'This function returns the objectId for the "EmployeeLayer", creating it if necessary.
    Private Function CreateLayer() As ObjectId
        Dim layerId As ObjectId 'the return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using trans As Transaction = db.TransactionManager.StartTransaction()
            'Get the layer table first, open for read as it may already be there
            Dim lt As LayerTable = trans.GetObject(db.LayerTableId, OpenMode.ForRead)

            'Check if EmployeeLayer exists...
            If lt.Has("EmployeeLayer") Then
                layerId = lt.Item("EmployeeLayer")
            Else
                'If not, create the layer here.
                Dim ltr As LayerTableRecord = New LayerTableRecord()
                ltr.Name = "EmployeeLayer" ' Set the layer name
                ltr.Color = Color.FromColorIndex(ColorMethod.ByAci, 2)
                ' it doesn't exist so add it, but first upgrade the open to write
                lt.UpgradeOpen()
                layerId = lt.Add(ltr)
                trans.AddNewlyCreatedDBObject(ltr, True)
            End If
            trans.Commit()
        End Using

        Return layerId
    End Function
#End Region

#Region "CreateDivision"
    Private Function CreateDivision(ByVal division As String, ByVal manager As String) As ObjectId

        Dim retId As ObjectId
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using trans As Transaction = db.TransactionManager.StartTransaction()
            'First, get the Named Objects Dictionary (NOD)...
            Dim NOD As DBDictionary = trans.GetObject(db.NamedObjectsDictionaryId, OpenMode.ForWrite, False)
            'Define a corporate level dictionary
            Dim acmeDict As DBDictionary
            ' here's another way to see if something exists, using try/catch instead of "has"
            Try
                'if it exists, just get it
                acmeDict = trans.GetObject(NOD.GetAt("ACME_DIVISION"), OpenMode.ForRead)
            Catch
                'Doesn't exist, so create one
                acmeDict = New DBDictionary()
                NOD.SetAt("ACME_DIVISION", acmeDict)
                trans.AddNewlyCreatedDBObject(acmeDict, True)
            End Try

            'Now get the division we want from acmeDict
            Dim divDict As DBDictionary
            Try
                divDict = trans.GetObject(acmeDict.GetAt(division), OpenMode.ForWrite)
            Catch
                divDict = New DBDictionary() 'Division doesn't exist, create one
                'Upgrade from read to write state
                acmeDict.UpgradeOpen()
                acmeDict.SetAt(division, divDict)
                trans.AddNewlyCreatedDBObject(divDict, True)
            End Try

            'Now get the manager info from the division
            'We need to add the name of the division supervisor.  We'll do this with another XRecord.
            Dim mgrXRec As Xrecord
            Try
                mgrXRec = trans.GetObject(divDict.GetAt("Department Manager"), OpenMode.ForWrite)
            Catch
                mgrXRec = New Xrecord()
                mgrXRec.Data = New ResultBuffer(New TypedValue(DxfCode.Text, manager))
                divDict.SetAt("Department Manager", mgrXRec)
                trans.AddNewlyCreatedDBObject(mgrXRec, True)
            End Try
            retId = mgrXRec.ObjectId
            trans.Commit()
        End Using

        Return retId
    End Function
#End Region

#Region "EmployeeCountCommand"
    <CommandMethod("EMPLOYEECOUNT")> _
      Public Sub EmployeeCount()
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction() 'Start the transaction.
                Dim nEmployeeCount As Integer = 0
                'First, get at the BlockTable, and the ModelSpace BlockTableRecord
                Dim bt As BlockTable = trans.GetObject(HostApplicationServices.WorkingDatabase.BlockTableId, OpenMode.ForRead)
                Dim btr As BlockTableRecord = trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead)

                'Now, here is the fun part.  This is where we iterate through ModelSpace:
                Dim id As ObjectId ' - First, dimension an ID variable used in the For Loop.
                For Each id In btr
                    Dim ent As Entity = trans.GetObject(id, OpenMode.ForRead, False) 'Use it to open the current object!
                    If TypeOf ent Is BlockReference Then 'We use .NET's RTTI to establish type.
                        nEmployeeCount += 1
                    End If
                Next
                ed.WriteMessage("Employees Found: {0}" + ControlChars.Lf, nEmployeeCount.ToString())
                trans.Commit()
            End Using
        Catch ex As System.Exception
            ed.WriteMessage("Error Counting Employees: " + ex.Message)
        End Try

    End Sub
#End Region

#Region "ListEmployee"
    'We want a command which will go through and list all the relevant employee data.
    Private Shared Sub ListEmployee(ByVal employeeId As ObjectId, ByRef saEmployeeList() As String)
        Dim nEmployeeDataCount As Integer
        Dim db As Database = HostApplicationServices.WorkingDatabase

        Using trans As Transaction = db.TransactionManager.StartTransaction() 'Start the transaction.
            Dim ent As Entity = trans.GetObject(employeeId, OpenMode.ForRead, False) 'Use it to open the current object!
            If TypeOf ent Is BlockReference Then 'We use .NET's RTTI to establish type.
                'Not all BlockReferences will have our employee data, so we must make sure we can handle failure
                Dim bHasOurDict As Boolean = True
                Dim EmployeeXRec As Xrecord = Nothing
                Try
                    Dim br As BlockReference = CType(ent, BlockReference)
                    Dim extDict As DBDictionary = trans.GetObject(br.ExtensionDictionary(), OpenMode.ForRead, False)
                    EmployeeXRec = trans.GetObject(extDict.GetAt("EmployeeData"), OpenMode.ForRead, False)
                Catch
                    bHasOurDict = False 'Something bad happened...our dictionary and/or XRecord is not accessible
                End Try
                If bHasOurDict Then 'If obtaining the Extension Dictionary, and our XRecord is successful...
                    'Stretch the employee list to fit three more entries...
                    ReDim Preserve saEmployeeList(saEmployeeList.GetUpperBound(0) + 4)
                    'Add Employee Name
                    Dim resBuf As TypedValue = EmployeeXRec.Data.AsArray(0)

                    saEmployeeList.SetValue(String.Format("{0}" + ControlChars.Lf, resBuf.Value), nEmployeeDataCount)
                    nEmployeeDataCount += 1

                    'Add the Employee Salary
                    resBuf = EmployeeXRec.Data.AsArray(1)
                    saEmployeeList.SetValue(String.Format("{0}" + ControlChars.Lf, resBuf.Value), nEmployeeDataCount)
                    nEmployeeDataCount += 1

                    'Add the Employee Division
                    resBuf = EmployeeXRec.Data.AsArray(2)
                    Dim str As String = resBuf.Value()
                    saEmployeeList.SetValue(String.Format("{0}" + ControlChars.Lf, resBuf.Value), nEmployeeDataCount)
                    nEmployeeDataCount += 1


                    'Now, we get the Boss' name from the corporate dictionary...
                    'Dig into the NOD and get it.
                    Dim NOD As DBDictionary = trans.GetObject(db.NamedObjectsDictionaryId, OpenMode.ForRead, False)
                    Dim acmeDict As DBDictionary = trans.GetObject(NOD.GetAt("ACME_DIVISION"), OpenMode.ForRead)
                    'Notice we use the XRecord data directly...
                    Dim salesDict As DBDictionary = trans.GetObject(acmeDict.GetAt(EmployeeXRec.Data.AsArray(2).Value), OpenMode.ForRead)
                    Dim salesXRec As Xrecord = trans.GetObject(salesDict.GetAt("Department Manager"), OpenMode.ForRead)
                    'Finally, write the employee's supervisor to the commandline
                    resBuf = salesXRec.Data.AsArray(0)
                    saEmployeeList.SetValue(String.Format("{0}" + ControlChars.Lf, resBuf.Value), nEmployeeDataCount)
                    nEmployeeDataCount += 1
                End If
            End If
            trans.Commit()
        End Using

    End Sub

#End Region

#Region "ListEmployeesCommand"
    <CommandMethod("LISTEMPLOYEES")> _
    Public Sub List()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        Try
            Dim Opts As New PromptSelectionOptions()

            'Build a filter list so that only block references are selected
            Dim filList() As TypedValue = {New TypedValue(DxfCode.Start, "INSERT")}

            Dim filter As SelectionFilter = New SelectionFilter(filList)
            Dim res As PromptSelectionResult = ed.GetSelection(Opts, filter)

            'Do nothing if selection is unsuccessful
            If Not res.Status = PromptStatus.OK Then Return
            Dim SS As Autodesk.AutoCAD.EditorInput.SelectionSet = res.Value
            Dim idArray As ObjectId() = SS.GetObjectIds()

            Dim employeeId As ObjectId
            Dim saEmployeeList(4) As String

            'collect all employee details in saEmployeeList array
            For Each employeeId In idArray
                ListEmployee(employeeId, saEmployeeList)

                'Print employee details to the command line
                Dim employeeDetail As String
                For Each employeeDetail In saEmployeeList
                    ed.WriteMessage(employeeDetail)
                Next
                'separator
                ed.WriteMessage("----------------------" + vbCrLf)
            Next
        Catch ex As System.Exception
            ed.WriteMessage("Error Listing Employees: " + ex.Message)
        End Try
    End Sub
#End Region

End Class