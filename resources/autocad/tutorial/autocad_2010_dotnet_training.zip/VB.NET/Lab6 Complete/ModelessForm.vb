Imports System.Drawing

Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry

Imports Autodesk.AutoCAD.Windows
Imports Autodesk.AutoCAD.Runtime

Public Class ModelessForm
    Inherits System.Windows.Forms.UserControl

    Private Sub label4_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Label4.MouseMove
        If (System.Windows.Forms.Control.MouseButtons = System.Windows.Forms.MouseButtons.Left) Then
            'start dragDrop operation, MyDropTarget will be called when the cursor enters the AutoCAD view area.
            Application.DoDragDrop(Me, Me, System.Windows.Forms.DragDropEffects.All, New MyDropTarget())
        End If
    End Sub

    Dim ps As Autodesk.AutoCAD.Windows.PaletteSet = Nothing

    <CommandMethod("Palette")> _
    Public Sub createPalette()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            If ps Is Nothing Then
                ps = New Autodesk.AutoCAD.Windows.PaletteSet("Employee Palette")

                ' ps.Style = PaletteSetStyles.ShowTabForSingle
                ' ps.Opacity = 65

                Dim myForm As ModelessForm = New ModelessForm()
                ps.Add("Employee Palette", myForm)
                ps.MinimumSize = New System.Drawing.Size(300, 300)
                ps.Visible = True
            End If
        Catch ex As System.Exception
            ed.WriteMessage("Error Creating Palette: " + ex.Message)
        End Try
    End Sub



#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tb_Salary As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tb_Division As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tb_Name As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tb_Salary = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tb_Division = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tb_Name = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(16, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 23)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Employee Details"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(32, 280)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 16)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Drag to Create Employee"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 208)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 16)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Salary"
        '
        'tb_Salary
        '
        Me.tb_Salary.Location = New System.Drawing.Point(16, 224)
        Me.tb_Salary.Name = "tb_Salary"
        Me.tb_Salary.Size = New System.Drawing.Size(184, 20)
        Me.tb_Salary.TabIndex = 20
        Me.tb_Salary.Text = "42000"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 16)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Division"
        '
        'tb_Division
        '
        Me.tb_Division.Location = New System.Drawing.Point(16, 152)
        Me.tb_Division.Name = "tb_Division"
        Me.tb_Division.Size = New System.Drawing.Size(184, 20)
        Me.tb_Division.TabIndex = 18
        Me.tb_Division.Text = "Sales"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 16)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Name"
        '
        'tb_Name
        '
        Me.tb_Name.Location = New System.Drawing.Point(16, 80)
        Me.tb_Name.Name = "tb_Name"
        Me.tb_Name.Size = New System.Drawing.Size(184, 20)
        Me.tb_Name.TabIndex = 16
        Me.tb_Name.Text = "Delton T. Cransley"
        '
        'ModelessForm
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.Label4, Me.Label3, Me.tb_Salary, Me.Label2, Me.tb_Division, Me.Label1, Me.tb_Name})
        Me.Name = "ModelessForm"
        Me.Size = New System.Drawing.Size(216, 352)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class

Public Class MyDropTarget
    Inherits Autodesk.AutoCAD.Windows.DropTarget

    Public Overrides Sub OnDrop(ByVal e As System.Windows.Forms.DragEventArgs)
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Try
            Dim pt As Point3d = ed.PointToWorld(New Point(e.X, e.Y))

            Using docLock As DocumentLock = Application.DocumentManager.MdiActiveDocument.LockDocument()
                Dim ctrl As ModelessForm = e.Data.GetData(GetType(ModelessForm))
                AsdkClass1.CreateDivision(ctrl.tb_Division.Text, AsdkClass1.sDivisionManager)
                AsdkClass1.CreateEmployee(ctrl.tb_Name.Text, ctrl.tb_Division.Text, ctrl.tb_Salary.Text, pt)
            End Using
        Catch ex As System.Exception
            ed.WriteMessage("Error Handling OnDrop: " + ex.Message)
        End Try
    End Sub
End Class