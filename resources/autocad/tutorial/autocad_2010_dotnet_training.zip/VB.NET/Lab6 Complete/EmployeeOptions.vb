Imports Autodesk.AutoCAD.ApplicationServices

Public Class EmployeeOptions
    Inherits System.Windows.Forms.UserControl

    Public Shared sDivisionDefault As String
    Public Shared sDivisionManager As String

    Public Sub OnOk()
        AsdkClass1.sDivisionDefault = tb_EmployeeDivision.Text
        AsdkClass1.sDivisionManager = tb_DivisionManager.Text
    End Sub

    Public Shared Sub AddTabDialog()
        AddHandler Application.DisplayingOptionDialog, AddressOf TabHandler
    End Sub

    Public Shared Sub RemoveTabDialog()
        RemoveHandler Application.DisplayingOptionDialog, AddressOf TabHandler
    End Sub

    Private Shared Sub TabHandler(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.TabbedDialogEventArgs)
        sDivisionDefault = AsdkClass1.sDivisionDefault
        sDivisionManager = AsdkClass1.sDivisionManager

        Dim EmployeeOptionsPage As EmployeeOptions = New EmployeeOptions()
        e.AddTab("Acme Employee Options", _
        New TabbedDialogExtension( _
            EmployeeOptionsPage, _
            New TabbedDialogAction(AddressOf EmployeeOptionsPage.OnOk)))
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tb_DivisionManager As System.Windows.Forms.TextBox
    Friend WithEvents tb_EmployeeDivision As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tb_DivisionManager = New System.Windows.Forms.TextBox()
        Me.tb_EmployeeDivision = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 16)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Default Division Manager"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Default Employee Division"
        '
        'tb_DivisionManager
        '
        Me.tb_DivisionManager.Location = New System.Drawing.Point(16, 80)
        Me.tb_DivisionManager.Name = "tb_DivisionManager"
        Me.tb_DivisionManager.Size = New System.Drawing.Size(184, 20)
        Me.tb_DivisionManager.TabIndex = 9
        Me.tb_DivisionManager.Text = sDivisionManager
        '
        'tb_EmployeeDivision
        '
        Me.tb_EmployeeDivision.Location = New System.Drawing.Point(16, 32)
        Me.tb_EmployeeDivision.Name = "tb_EmployeeDivision"
        Me.tb_EmployeeDivision.Size = New System.Drawing.Size(184, 20)
        Me.tb_EmployeeDivision.TabIndex = 8
        Me.tb_EmployeeDivision.Text = sDivisionDefault
        '
        'EmployeeOptions
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label2, Me.Label1, Me.tb_DivisionManager, Me.tb_EmployeeDivision})
        Me.Name = "EmployeeOptions"
        Me.Size = New System.Drawing.Size(216, 136)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
