Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices

Imports Autodesk.AutoCAD.Windows
Imports Autodesk.AutoCAD.Runtime


Public Class ModalForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents SelectEmployeeButton As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tb_Division As System.Windows.Forms.TextBox
    Friend WithEvents tb_Salary As System.Windows.Forms.TextBox
    Friend WithEvents tb_Name As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button2 = New System.Windows.Forms.Button
        Me.SelectEmployeeButton = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.tb_Division = New System.Windows.Forms.TextBox
        Me.tb_Salary = New System.Windows.Forms.TextBox
        Me.tb_Name = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(174, 88)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(104, 32)
        Me.Button2.TabIndex = 22
        Me.Button2.Text = "Close"
        '
        'SelectEmployeeButton
        '
        Me.SelectEmployeeButton.Location = New System.Drawing.Point(174, 32)
        Me.SelectEmployeeButton.Name = "SelectEmployeeButton"
        Me.SelectEmployeeButton.Size = New System.Drawing.Size(104, 32)
        Me.SelectEmployeeButton.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(14, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(144, 16)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Division"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(14, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(144, 16)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Salary"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(14, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 16)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Name"
        '
        'tb_Division
        '
        Me.tb_Division.Location = New System.Drawing.Point(14, 72)
        Me.tb_Division.Name = "tb_Division"
        Me.tb_Division.Size = New System.Drawing.Size(144, 20)
        Me.tb_Division.TabIndex = 17
        '
        'tb_Salary
        '
        Me.tb_Salary.Location = New System.Drawing.Point(14, 120)
        Me.tb_Salary.Name = "tb_Salary"
        Me.tb_Salary.Size = New System.Drawing.Size(144, 20)
        Me.tb_Salary.TabIndex = 16
        '
        'tb_Name
        '
        Me.tb_Name.Location = New System.Drawing.Point(14, 24)
        Me.tb_Name.Name = "tb_Name"
        Me.tb_Name.Size = New System.Drawing.Size(144, 20)
        Me.tb_Name.TabIndex = 15
        '
        'ModalForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 165)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.SelectEmployeeButton)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tb_Division)
        Me.Controls.Add(Me.tb_Salary)
        Me.Controls.Add(Me.tb_Name)
        Me.Name = "ModalForm"
        Me.Text = "ModalForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub SelectEmployeeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectEmployeeButton.Click
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Using userInteraction As EditorUserInteraction = ed.StartUserInteraction(Me)
            Try
                Using trans As Transaction = db.TransactionManager.StartTransaction()
                    Dim prEnt As PromptEntityOptions = New PromptEntityOptions("Select an Employee")
                    Dim prEntRes As PromptEntityResult = ed.GetEntity(prEnt)
                    If prEntRes.Status <> PromptStatus.OK Then
                        Throw New System.Exception("Error or User Cancelled")
                    End If

                    Dim saEmployeeList(-1) As String 'This is right...it is redimed in the called function.

                    AsdkClass1.ListEmployee(prEntRes.ObjectId, saEmployeeList)
                    If (saEmployeeList.Length = 4) Then
                        tb_Name.Text = saEmployeeList(0)
                        tb_Salary.Text = saEmployeeList(1)
                        tb_Division.Text = saEmployeeList(2)
                    End If
                End Using
            Catch ex As System.Exception
                MsgBox("Error Selecting Employee: " + ex.Message)
            Finally
                userInteraction.End()
            End Try
        End Using
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    <CommandMethod("MODALFORM")> _
    Public Sub ShowModalForm()
        Dim modalForm As ModalForm = New ModalForm()
        Application.ShowModalDialog(modalForm)
    End Sub

    Private Sub ModalForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SelectEmployeeButton.Image = Autodesk.AutoCAD.Windows.Visuals.PickBitmap
        SelectEmployeeButton.Size = New Drawing.Size(28, 28)
    End Sub
End Class
