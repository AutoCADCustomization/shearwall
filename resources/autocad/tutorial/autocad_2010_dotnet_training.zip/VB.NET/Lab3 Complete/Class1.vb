' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Colors

Public Class AsdkClass1

  'This function creates a new BlockReference to the "EmployeeBlock" object,
  'and adds it to ModelSpace.
  <CommandMethod("CREATE")> _
  Public Sub CreateEmployee()

    ' get the current working database
    Dim db As Database = HostApplicationServices.WorkingDatabase()
    ' start a transaction object which will be in charge of commiting changes to the drawing
        Dim trans As Transaction = db.TransactionManager.StartTransaction() ' Demonstrates a manual way of using Transactions...
        Try

            ' open the block table for write
            Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
            ' and now open model space
            Dim btr As BlockTableRecord = trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite)
            'Create the block reference...use the return from CreateEmployeeDefinition directly!
            Dim br As New BlockReference(New Point3d(10, 10, 0), CreateEmployeeDefinition())
            btr.AppendEntity(br) 'Add the reference to ModelSpace

            'inform the transaction about the new object
            trans.AddNewlyCreatedDBObject(br, True)

            ' if all is ok, then commit the changes - this will close everything up
            trans.Commit()

        Catch ex As System.Exception
            ' uh oh, problem
            ' call dispose to close all the open entities, but not commit anything to the drawing
            trans.Dispose()
            ' lets display what the problem is
            MsgBox("Error in Create Command" + ex.Message)
        End Try

    End Sub

  'This function returns the ObjectId for the BlockTableRecord called "EmployeeBlock",
  'creating it if necessary.  The block contains three entities - circle, text 
  'and ellipse.
    Private Function CreateEmployeeDefinition() As ObjectId

        Dim newBtrId As ObjectId 'The return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase() 'save some space
        Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction

            ' Now, drill into the database and obtain a reference to the BlockTable
            Dim bt As BlockTable = trans.GetObject(db.BlockTableId, OpenMode.ForWrite)
            If (bt.Has("EmployeeBlock")) Then
                newBtrId = bt("EmployeeBlock") 'Alreayd there...no need to recreate it!
            Else
                Dim center As New Point3d(10, 10, 0) 'convenient declaration...

                'Declare and define the entities we want to add:
                'Circle:
                Dim circle As Circle = New Circle(center, Vector3d.ZAxis, 2.0)
                'Text:
                Dim text As MText = New MText()
                text.Contents = "Earnest Shackleton"
                text.Location = center
                'Ellipse:
                Dim ellipse As Ellipse = New Ellipse(center, Vector3d.ZAxis, New Vector3d(3, 0, 0), 0.5, 0.0, 0.0)

                'Next, create a layer with the helper function, and assign
                'the layer to our entities.
                Dim empId As ObjectId = CreateLayer()
                text.LayerId = empId
                circle.LayerId = empId
                ellipse.LayerId = empId
                'Set the color for each entity irrespective of the layer's color.
                text.ColorIndex = 2
                circle.ColorIndex = 1
                ellipse.ColorIndex = 3

                'Create a new block definition called EmployeeBlock
                Dim newBtr As BlockTableRecord = New BlockTableRecord()
                newBtr.Name = "EmployeeBlock"
                newBtrId = bt.Add(newBtr) 'Add the block, and set the id as the return value of our function
                'Let the transaction know about any object/entity you add to the database!
                trans.AddNewlyCreatedDBObject(newBtr, True)

                newBtr.AppendEntity(circle) 'Append our entities...
                newBtr.AppendEntity(text)
                newBtr.AppendEntity(ellipse)
                trans.AddNewlyCreatedDBObject(circle, True) 'Again, let the transaction know about our newly added entities.
                trans.AddNewlyCreatedDBObject(text, True)
                trans.AddNewlyCreatedDBObject(ellipse, True)
            End If
            ' if all is ok, then commit the changes - this will close everything up
            trans.Commit()
        End Using
        Return newBtrId
    End Function
    'This function returns the objectId for the "EmployeeLayer", creating it if necessary.
    Private Function CreateLayer() As ObjectId
        Dim layerId As ObjectId 'the return value for this function
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using trans As Transaction = db.TransactionManager.StartTransaction()
            'Get the layer table first, open for read as it may already be there
            Dim lt As LayerTable = trans.GetObject(db.LayerTableId, OpenMode.ForRead)

            'Check if EmployeeLayer exists...
            If lt.Has("EmployeeLayer") Then
                layerId = lt.Item("EmployeeLayer")
            Else
                'If not, create the layer here.
                Dim ltr As LayerTableRecord = New LayerTableRecord()
                ltr.Name = "EmployeeLayer" ' Set the layer name
                ltr.Color = Color.FromColorIndex(ColorMethod.ByAci, 2)
                ' it doesn't exist so add it, but first upgrade the open to write
                lt.UpgradeOpen()
                layerId = lt.Add(ltr)
                trans.AddNewlyCreatedDBObject(ltr, True)
            End If
            trans.Commit()
        End Using

        Return layerId
    End Function

End Class
